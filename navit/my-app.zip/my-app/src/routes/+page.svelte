<script>
    import Divs from "$lib/Divs/Divs.svelte";
</script>
<div>
    <Divs/>
</div>
