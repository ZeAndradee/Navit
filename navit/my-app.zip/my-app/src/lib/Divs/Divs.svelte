<script>
  let totalPacientesAtivos = 20;
  let totalPacientesInativos = 10;
  let pacientesAAtender = 5;
</script>

<style>
  .container {
    display: flex;
    width: 793px;
    padding-bottom: 0px;
    justify-content: space-between;
    align-items: center;
  }

  .section {
    display: flex;
    flex-direction: column;
    margin-right: 20px;
  }

  .header {
    color: #151515;
    font-family: Inter;
    font-size: 24px;
    font-style: normal;
    font-weight: 700;
    line-height: 64px;
  }

  .block {
    color: #666;
    font-family: Inter;
    font-size: 12px;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
  }

  .variable {
    color: var(--Black, #151515);
    font-family: Inter;
    font-size: 18px;
    font-style: normal;
    font-weight: 700;
    line-height: normal;
    margin-right: 5px;
  }
</style>

<div class="container">
  <div class="section">
    <div class="header">Seus prontuários</div>
  </div>

  <div class="section">
    <div class="block">
      <span class="variable">{totalPacientesAtivos}</span>Pacientes ativos
    </div>
  </div>

  <div class="section">
    <div class="block">
      <span class="variable">{totalPacientesInativos}</span>Pacientes inativos
    </div>
  </div>

  <div class="section">
    <div class="block">
      <span class="variable">{pacientesAAtender}</span>Pacientes a atender
    </div>
  </div>
</div>

  